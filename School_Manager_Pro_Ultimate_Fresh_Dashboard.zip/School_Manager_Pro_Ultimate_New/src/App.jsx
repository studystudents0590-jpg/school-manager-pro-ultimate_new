import React, { useMemo, useState } from "react";
import "./App.css";

const categories = [
  {
    title: "Super Admin",
    subtitle: "Control and manage all schools",
    icon: "🛡️",
    color: "violet",
    panels: [
      ["Dashboard", "▦", "Overview of the complete platform", true],
      ["Schools Management", "🏫", "Create and manage schools", true],
      ["School Admins", "👤", "Manage school administrator accounts", false],
      ["Permissions", "🔐", "Roles and access permissions", false],
    ],
  },
  {
    title: "Academic Management",
    subtitle: "Students, staff, classes and learning",
    icon: "🎓",
    color: "blue",
    panels: [
      ["Students", "👨‍🎓", "Student records and profiles", false],
      ["Admission", "📝", "New student admission", false],
      ["Teachers & Staff", "👩‍🏫", "Staff records and management", false],
      ["Classes & Sections", "🏫", "Class and section setup", false],
      ["Subjects", "📚", "Subject allocation", false],
      ["Timetable", "🕒", "Class schedules", false],
      ["Attendance", "📋", "Student and staff attendance", false],
      ["Examinations", "✍️", "Exam planning and schedules", false],
      ["Results & Report Cards", "📊", "Marks and student report cards", false],
    ],
  },
  {
    title: "Finance Management",
    subtitle: "Fees, collections and accounts",
    icon: "💳",
    color: "green",
    panels: [
      ["Fee Collection", "💰", "Record student fee payments", false],
      ["Fee Dues", "⏳", "Pending fee details", false],
      ["Student Ledger", "📒", "Student-wise fee history", false],
      ["Fee Receipts", "🧾", "Payment receipts", false],
      ["Discount & Scholarship", "🎓", "Fee concessions and scholarships", false],
      ["Expenses", "💸", "School expense records", false],
      ["Financial Reports", "📈", "Income and expense reports", false],
    ],
  },
  {
    title: "Communication",
    subtitle: "Connect school, parents and students",
    icon: "💬",
    color: "orange",
    panels: [
      ["Parent Portal", "👨‍👩‍👧", "Parent access and updates", false],
      ["Notices", "📢", "School announcements", false],
      ["SMS & Notifications", "🔔", "Messages and alerts", false],
      ["Homework", "📖", "Homework sharing and tracking", false],
    ],
  },
  {
    title: "Other Services",
    subtitle: "Additional school operations",
    icon: "🧰",
    color: "slate",
    panels: [
      ["Certificates", "📜", "Generate school certificates", false],
      ["ID Cards", "🪪", "Student and staff identity cards", false],
      ["Library", "📚", "Books and issue records", false],
      ["Transport", "🚌", "Routes and transport records", false],
      ["Settings", "⚙️", "School and application settings", false],
      ["Backup & Security", "🔒", "Data backup and security tools", false],
    ],
  },
];

export default function App() {
  const [activePanel, setActivePanel] = useState("Dashboard");
  const [query, setQuery] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);

  const allPanels = useMemo(
    () => categories.flatMap((category) =>
      category.panels.map(([name, icon, description, ready]) => ({
        name, icon, description, ready, category: category.title
      }))
    ), []
  );

  const active = allPanels.find((panel) => panel.name === activePanel);

  const openPanel = (name) => {
    setActivePanel(name);
    setMobileMenu(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const visibleCategories = categories.map((category) => ({
    ...category,
    panels: category.panels.filter(([name]) =>
      name.toLowerCase().includes(query.toLowerCase())
    ),
  })).filter((category) => category.panels.length > 0);

  return (
    <div className="smp-app">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark">S</div>
          <div><strong>School Manager</strong><span>PRO ULTIMATE</span></div>
          <button className="mobile-close" onClick={() => setMobileMenu(false)}>×</button>
        </div>
        <div className="side-label">WORKSPACE</div>
        <button className={`side-link ${activePanel === "Dashboard" ? "selected" : ""}`} onClick={() => openPanel("Dashboard")}>
          <span>▦</span> Dashboard
        </button>
        <div className="side-label side-label-spaced">CATEGORIES</div>
        {categories.map((category) => (
          <div className="side-category" key={category.title}>
            <div className="side-category-title">{category.icon} {category.title}</div>
            {category.panels.map(([name, icon]) => (
              <button key={name} className={`side-link nested ${activePanel === name ? "selected" : ""}`} onClick={() => openPanel(name)}>
                <span>{icon}</span>{name}
              </button>
            ))}
          </div>
        ))}
        <div className="sidebar-foot"><span className="online-dot" /> Local dashboard preview</div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <button className="menu-toggle" onClick={() => setMobileMenu(true)}>☰</button>
          <div className="crumb">School Manager <span>/</span> {activePanel}</div>
          <div className="profile"><div className="avatar">SA</div><div><b>Super Admin</b><small>Administrator</small></div></div>
        </header>

        <div className="page-wrap">
          {activePanel === "Dashboard" ? (
            <>
              <section className="hero">
                <div>
                  <div className="eyebrow">SCHOOL MANAGEMENT PLATFORM</div>
                  <h1>Welcome to School Manager Pro</h1>
                  <p>Manage every school operation from one organized dashboard.</p>
                  <div className="hero-tags"><span>5 Categories</span><span>{allPanels.length} Modules</span><span>Mobile friendly</span></div>
                </div>
                <div className="hero-art">🏫</div>
              </section>

              <div className="section-head">
                <div><h2>Management Categories</h2><p>Choose a category or open any panel directly.</p></div>
                <div className="search-box"><span>⌕</span><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search panels..." /></div>
              </div>

              <div className="category-list">
                {visibleCategories.map((category) => (
                  <section className={`category-card ${category.color}`} key={category.title}>
                    <div className="category-heading">
                      <div className="category-icon">{category.icon}</div>
                      <div><h3>{category.title}</h3><p>{category.subtitle}</p></div>
                      <span className="module-count">{category.panels.length} Panels</span>
                    </div>
                    <div className="panel-grid">
                      {category.panels.map(([name, icon, description, ready]) => (
                        <button className="panel-tile" key={name} onClick={() => openPanel(name)}>
                          <span className="tile-icon">{icon}</span>
                          <span className="tile-copy"><b>{name}</b><small>{description}</small></span>
                          <span className="tile-arrow">↗</span>
                        </button>
                      ))}
                    </div>
                  </section>
                ))}
                {visibleCategories.length === 0 && <div className="no-results">No matching panels found.</div>}
              </div>
            </>
          ) : (
            <section className="module-page">
              <button className="back-link" onClick={() => openPanel("Dashboard")}>← Back to Dashboard</button>
              <div className="module-banner">
                <div className="module-symbol">{active?.icon || "▦"}</div>
                <div><div className="eyebrow">{active?.category || "SCHOOL MANAGER"}</div><h1>{activePanel}</h1><p>{active?.description}</p></div>
              </div>
              <div className="setup-card">
                <div className="setup-icon">🚧</div>
                <div className="setup-status">MODULE SETUP PENDING</div>
                <h2>This panel is added to your dashboard</h2>
                <p>The dashboard navigation is ready. We will build this panel's working features one by one, starting with the module you choose.</p>
                <button className="primary-button" onClick={() => openPanel("Dashboard")}>Return to all categories</button>
              </div>
            </section>
          )}
          <footer className="footer">School Manager Pro Ultimate <span>•</span> Dashboard foundation</footer>
        </div>
      </main>
      {mobileMenu && <button className="scrim" aria-label="Close menu" onClick={() => setMobileMenu(false)} />}
    </div>
  );
}
